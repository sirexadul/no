plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.nowidget"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.nowidget"
        minSdk = 28            // GLOBAL_ACTION_LOCK_SCREEN requires API 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = true; isShrinkResources = true }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
// No dependencies on purpose: keeps the APK tiny.
