package com.example.nowidget

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Only exposes GLOBAL_ACTION_LOCK_SCREEN, the system's own "power button" lock path
 * (biometric unlock keeps working afterwards). Listens to no events, reads no screen content.
 */
class LockAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
    override fun onDestroy() { instance = null; super.onDestroy() }

    companion object {
        @Volatile private var instance: LockAccessibilityService? = null

        fun lockScreen(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
    }
}
