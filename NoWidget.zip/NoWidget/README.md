# no — 2×2 lock-screen widget
Open this folder in Android Studio, let Gradle sync, then Run (or Build > Build APK).
On the phone: add the "no" widget -> tap it once -> enable "no" under Accessibility -> tap again.
